<?php
/**
 * To change this license header, choose License Headers in Project Properties
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://izooto.com for more information.
 *
 *  @author    Datability Solutions Inc;
 *  @copyright 2015-2019 Izooto
 *  @license   https://izooto.com
 */

if (!defined('_PS_VERSION_')) {
    exit();
}

class Ps_Izooto extends Module
{
    protected $error = false;
    protected $config_form = false;
    protected $manifest_file = "manifest.json";
    protected $service_file = "service-worker.js";
    protected $root_path = _PS_MODULE_DIR_ . "../";
    protected $izooto_api_url = "api.izooto.com";
    protected $filePermission = false;

    public function __construct()
    {
        $this->name = 'ps_izooto';
        $this->version = '1.0.0';
        $this->need_instance = 0;
        $this->tab = 'others';
        $this->author = 'Datability Solutions Inc';
        $this->bootstrap = true;
        parent::__construct();
        $this->initContext();
        $this->displayName = $this->l('iZooto Web Push Notifications');
        $this->description = $this->l('Automated notifications to Recover Abandoned Carts,Drive Sales');
        $this->confirmUninstall = $this->l('Are you sure about removing these details?');
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        return (parent::install() && $this->registerHook('productfooter') &&
                $this->registerHook('displayProductExtraContent') &&
                $this->registerHook('actionCartSave') &&
                $this->registerHook('actionAuthentication') &&
                $this->registerHook('createaccount') &&
                $this->registerHook('orderConfirmation') &&
                $this->registerHook('backBeforePayment') &&
                $this->registerHook('productTab') &&
                $this->registerHook('header') &&
                $this->registerHook('footer') &&
                $this->registerHook('actionBeforeCartUpdateQty'));
    }
    
    public function uninstall()
    {
        Configuration::deleteByName('IZOOTO_ID');
        Configuration::deleteByName('IZOOTO_UID');
        Configuration::deleteByName('IZOOTO_PID');
        Configuration::deleteByName('IZOOTO_GCM_SENDER_ID');
        Configuration::deleteByName('IZOOTO_JS_URL');
        Configuration::deleteByName('IZOOTO_SW_URL');
        Configuration::deleteByName('IZOOTO_ACC_APP_KEY');
        Configuration::deleteByName('IZOOTO_ACC_SUBDOMAIN');
        Configuration::deleteByName('IZOOTO_ACC_PHONE');
        Configuration::deleteByName('IZOOTO_ACC_NAME');
        Configuration::deleteByName('IZOOTO_ACC_EMAIL');

        if (!parent::uninstall()) {
            return false;
        }
        return true;
    }
    
    private function initContext()
    {
        if (class_exists('Context')) {
            $this->context = Context::getContext();
        }
    }

    private function fileSetup()
    {
        try {
            $m_file = fopen($this->root_path . $this->manifest_file, "wr");
            $txt = " ";
            fwrite($m_file, $txt);
            fclose($m_file);

            $s_file = fopen($this->root_path . $this->service_file, "wr");
            fwrite($s_file, $txt);
            fclose($s_file);
            if (file_exists($this->root_path . $this->service_file) && file_exists($this->root_path . $this->manifest_file)) {
                if (is_writable($this->root_path . $this->service_file) && is_writable($this->root_path . $this->service_file)) {
                    $this->filePermission = true;
                    
                    $izooto_sender_id = Tools::getValue('IZOOTO_GCM_SENDER_ID', Configuration::get('IZOOTO_GCM_SENDER_ID'));
                    $izooto_sw_url = Tools::getValue('IZOOTO_SW_URL', Configuration::get('IZOOTO_SW_URL'));
                    
                    $str = '{"gcm_sender_id": "' . $izooto_sender_id . '"}';
                    file_put_contents($this->root_path . $this->manifest_file, $str);

                    $str = "importScripts('https://" . $izooto_sw_url . "');";
                    file_put_contents($this->root_path . $this->service_file, $str);
                } else {
                    $massage = $this->root_path . $this->service_file . " OR "
                            . $this->root_path . $this->manifest_file . " File Is not writable::";

                    return $this->displayError($this->trans($massage, array(), 'Admin.Notifications.Error'));
                }
            } else {
                $massage = $this->root_path . $this->service_file . " OR "
                        . $this->root_path . $this->service_file . " File Not exist::";

                return $this->displayError($this->trans($massage, array(), 'Admin.Notifications.Error'));
            }
        } catch (Exception $ex) {
            return $this->displayError($this->trans($ex->getMessage(), array(), 'Admin.Notifications.Error'));
        }
        return "";
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {

        $this->context->smarty->assign('module_dir', $this->_path);

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        /**
         * If values have been submitted in the form, process.
         */
        if (((bool) Tools::isSubmit('submitIzootoModule')) == true) {
            $output .= $this->postProcess();
        }

        $resFileSetup = $this->fileSetup();

        $output .= $resFileSetup;
        $output .= $this->renderForm();

        return $output;
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitIzootoModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
                . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'col' => 6,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-pencil"></i>',
                        'desc' => $this->l('Enter a valid iZooto ID'),
//                        'desc' => $this->l('Enter a valid email address <a href="https://kapil.izooto.com/integration-details">Click for URL:</a>'),
                        'name' => 'IZOOTO_ID',
                        'label' => $this->l('iZooto ID'),
                    ),
//                    array(
//                        'type' => 'text',
//                        'name' => 'IZOOTO_ACCOUNT_PASSWORD',
//                        'label' => $this->l('Password'),
//                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
                'IZOOTO_ID' => Tools::getValue('IZOOTO_ID', Configuration::get('IZOOTO_ID'))
            );
    }
    /**
     * Set values for the inputs.
     */
    protected function getIzootoConfigValues()
    {
        $izooto_id = Tools::getValue('IZOOTO_ID', Configuration::get('IZOOTO_ID'));

        $requesturl = "http://" . $this->izooto_api_url . "/wp/index.php?key=" . $izooto_id . "&version=3.3.5";
        try {
            $ch = curl_init($requesturl);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

            $result = curl_exec($ch);
        } catch (Exception $ex) {
            return array(
                'ERROR' => 1,
                'ERROR_MSG' => "Exception Occure. " . $ex->getMessage(),
                'IZOOTO_ID' => $izooto_id,
            );
        }
        $izooto_detail = json_decode($result, 1);
        if (!$izooto_detail['error']) {
            return array(
                'IZOOTO_ID' => $izooto_id,
                'IZOOTO_UID' => $izooto_detail["uid"],
                'IZOOTO_PID' => $izooto_detail["pid"],
                'IZOOTO_GCM_SENDER_ID' => $izooto_detail["gcmSenderId"],
                'IZOOTO_JS_URL' => $izooto_detail["js-url"],
                'IZOOTO_SW_URL' => $izooto_detail["sw-url"],
                'IZOOTO_ACC_APP_KEY' => $izooto_detail["appKey"],
                'IZOOTO_ACC_SUBDOMAIN' => $izooto_detail["subdomain"],
                'IZOOTO_ACC_PHONE' => $izooto_detail["phone"],
                'IZOOTO_ACC_NAME' => $izooto_detail["name"],
                'IZOOTO_ACC_EMAIL' => $izooto_detail["email"],
            );
        } else {
            return array(
                'ERROR' => 1,
                'ERROR_MSG' => "Error In Site Token",
                'IZOOTO_ID' => $izooto_id,
            );
        }
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getIzootoConfigValues();
        if (isset($form_values['ERROR']) && $form_values['ERROR']) {
            return $this->displayError($this->trans($form_values['ERROR_MSG'], array(), 'Admin.Notifications.Error'));
        }

        foreach ($form_values as $key => $value) {
            Configuration::updateValue($key, $value);
        }
        return "";
    }

    /*
     * Implement HookHeader Function;
     * Set the properties of the izooto module in header like Identify;
     * Set head.tpl and identifyusers.tpl;
     */

    public function hookHeader($params)
    {
        $this->registerHook('footer');
        $smarty = $this->context->smarty;
        $smarty->assign('undefind', $params);
        $izooto_id = Configuration::get('IZOOTO_ID');
        $js_url = Configuration::get('IZOOTO_JS_URL');
        
        $smarty->assign('izootoId', $izooto_id);
        $smarty->assign('izootoJsUrl', $js_url);
        
        $izooto_head = $smarty->fetch($this->local_path . 'views/templates/hook/head.tpl');
        return $izooto_head;
    }

    public function hookFooter()
    {
        $smarty = $this->context->smarty;
        $tpl_vars = $smarty->tpl_vars;
        if ($tpl_vars['page']->value["page_name"] == "category") {
            $carray = array(
                "collection_title"=>$tpl_vars['category']->value["name"],
                "collection_id" => $tpl_vars['category']->value["id"],
                "collection_image" => $tpl_vars['category']->value["image"]["bySize"]["category_default"]["url"],
                "collection_link" => $tpl_vars['page']->value["canonical"],
            );
            
            $catarray = json_encode($carray);

            $izootoparams = array_merge($this->izootoSystemProperty("collection_viewed"), array("val" => $catarray));
            $requesturl = 'https://et.izooto.com/evt';
            $result = $this->izootoMakeRequest($requesturl, $izootoparams);
            return $result;
        }
    }
    
    /*
     * Implement hookProductTab Function;
     * Track View Product Event;
     * Send View product detail on izooto vie curl;
     */
    
    public function hookDisplayProductExtraContent($params)
    {
        $cookie = $this->context->cookie;
        $value = $params['product'];
        $productarray = array();
        $currency = new CurrencyCore($cookie->id_currency);
        if (is_object($value)) {
            $id_image = Product::getCover($value->id);
            // get Image by id;
            if (count($id_image) > 0) {
                $image = new Image($id_image['id_image']);
                // get image full URL;
                $image_url = _PS_BASE_URL_ . _THEME_PROD_DIR_ . $image->getExistingImgPath() . '.jpg';
            }

            $link = new Link();
            $product_url = $link->getProductLink($value);
         
            $productarray["product_title"] = $value->name;
//            $productarray["product_sku"] = $value->id;
            $productarray["product_price"] = $value->price;
            $productarray["product_id"] = $value->id;
            $productarray["currency"] = $currency->iso_code;
            $productarray["product_link"] = $product_url;
            $productarray["product_cat_id"] = (int)$value->id_category_default;
            $productarray["product_cat_name"] = $value->category;
            $productarray["product_brandname"] = $value->manufacturer_name;
            $productarray["product_stock_availability"] = (int)$value->available_for_order;
            $productarray["product_image"] = $image_url;
            
            $parray = json_encode($productarray);

            $izootoparams = array_merge($this->izootoSystemProperty("product_viewed"), array("val" => $parray));
            $requesturl = 'https://et.izooto.com/evt';
            $result = $this->izootoMakeRequest($requesturl, $izootoparams);
            return $result;
        }
    }

    /*
     * Implement hookActionCartSave Function;
     * Track Cart Event Like Add to cart, Removed From cart, Total Product's In cart;
     * Track Cart Update;
     */

    public function hookActionCartSave($params)
    {
        $cookie = $this->context->cookie;
        $cart = $params['cart'];
        $cookies = $params['cookie'];
        $product_id = $productarray = $pro_qty = $padd = $productd = array();
        if (is_object($cart)) {
            $currency = new CurrencyCore($cookies->id_currency);

            $products = $cart->getProducts(true);
            $cartinfo = array("cart_price" => (float)$cart->getOrderTotal(),
            'cart_url' => _PS_BASE_URL_."/cart",
            'currency' => $currency->iso_code);
            foreach ($products as $value) {
                $i = $value['id_product'];
                $id_image = Product::getCover($value['id_product']);
                // get Image by id;
                if (count($id_image) > 0) {
                    $image = new Image($id_image['id_image']);
                    // get image full URL;
                    $image_url = _PS_BASE_URL_ . _THEME_PROD_DIR_ . $image->getExistingImgPath() . '.jpg';
                }


                $productarray[$i]["product_title"] = $value['name'];
//                $productarray[$i]["product_sku"] = $value['id_product'];
                $productarray[$i]["product_price"] = $value['price'];
                $productarray[$i]["product_id"] = (int)$value['id_product'];
                $productarray[$i]["product_cat_id"] = (int)$value['id_category_default'];
                $productarray[$i]["product_cat_name"] = $value['category'];
                $productarray[$i]["product_brandname"] = $value['manufacturer_name'];
                $productarray[$i]["product_stock_availability"] = (int)$value['available_for_order'];
                $productarray[$i]["product_image"] = $image_url;
                array_push($product_id, $value['id_product']);
                $pro_qty[$i] = $value['cart_quantity'];
            }

            $prev_cookie = $cookie->__get('xlcn_consumable_cart');
            $cookie->__set('xlcn_consumable_cart', implode(',', $product_id));

            $added = array_diff($product_id, explode(',', $prev_cookie));

            $parray = explode(',', $prev_cookie);
            if ($cookie->__get('xlcn_consumable_cart') == null) {
                $carray = null;
            } else {
                $carray = explode(',', $cookie->__get('xlcn_consumable_cart'));
            }

            if ((count($parray)) > (count($carray))) {
                $deleted = array_diff(explode(',', $prev_cookie), $product_id);
            } else {
                $deleted = array();
            }

            $adcount = count($added);
            $deletecount = count($deleted);

            // Track Add to Cart Event;
            if ($adcount) {
                foreach ($added as $id) {
                    $padd = $productarray[$id];
                    $parray = json_encode(array_merge($padd, $cartinfo));
                    $izootoparams = array_merge($this->izootoSystemProperty("added_to_cart"), array("val" => $parray));
                    $requesturl = 'https://et.izooto.com/evt';
                    $result = $this->izootoMakeRequest($requesturl, $izootoparams);
                }
            }

            //Track Removed From Cart Detail;
            //Get Delated Product Detail;
            if ($deletecount && !empty($prev_cookie)) {
                foreach ($deleted as $id) {
                    $product_object = new Product((int) $id, false, 1);
                    $i = $id;
                    $id_image = Product::getCover($id);
                    // get Image by id;
                    if (count($id_image) > 0) {
                        $image = new Image($id_image['id_image']);
                        // get image full URL;
                        $image_url = _PS_BASE_URL_ . _THEME_PROD_DIR_ . $image->getExistingImgPath() . '.jpg';
                    }

                    $productd['product_title'] = $product_object->name;
//                    $productd['product_sku'] = $product_object->id;
                    $productd['product_price'] = (float)$product_object->price;
                    $productd['product_id'] = $product_object->id;
//                    $productd[$i]['categories'] = $this->getCategoryNamesByProduct($id, true);
                    $productd['product_image'] = $image_url;
                    $productd['product_quantity'] = $product_object->quantity;
                    
                    $parray = json_encode(array_merge($productd, $cartinfo));
                    $izootoparams = array_merge($this->izootoSystemProperty("removed_from_cart"), array("val" => $parray));
                    $requesturl = 'https://et.izooto.com/evt';
                    $result = $this->izootoMakeRequest($requesturl, $izootoparams);
                }
            }

            //Track Update Cart Event;
            //Send current cart Status;
            $flage = false;
            if (!empty($prev_cookie) && ($cookie->__get('xlcn_izooto_cart') == true)) {
                $flage = true;
            }

            if ($adcount == 0 && $deletecount == 0 && $flage) {
                $pq = array();
                $pq = unserialize($cookie->__get('pro_qty'));
                foreach ($products as $value) {
                    if ($value['cart_quantity'] != $pq[$value['id_product']]) {
                        $padd = $productarray[$value['id_product']];
                        
                        $parray = json_encode(array_merge($padd, $cartinfo));
                        $izootoparams = array_merge($this->izootoSystemProperty("added_to_cart"), array("val" => $parray));
                        $requesturl = 'https://et.izooto.com/evt';
                        $result = $this->izootoMakeRequest($requesturl, $izootoparams);
                    }
                }
            }

            $cookie->__set('pro_qty', serialize($pro_qty));
            $cookie->__set('xlcn_izooto_cart', false);
            return $result;
        }
    }

    public function hookCreateAccount($params)
    {
        
        $update_array = array_filter(array("firstname" => $params['newCustomer']->firstname,
                "lastname" => $params['newCustomer']->lastname,
                "active_state" => $params['newCustomer']->active == true ? 1 : 0,
                "newsletter" => $params['newCustomer']->newsletter == 1 ? 1 : 0,
                "customer_id" => (int)$params['newCustomer']->id,
                "customer_email" => $params['newCustomer']->email,
            ));

            $uarray = json_encode($update_array);
            $izootoparams = array_merge($this->izootoSystemProperty("customer_sign_up"), array("val" => $uarray));

            $requesturl = 'http://et.izooto.com/evt';
            $result = $this->izootoMakeRequest($requesturl, $izootoparams);
            
            return $result;
    }

    public function izootoIdentify($phone, $cookie)
    {
        $identity = array("customer_id" => $this->context->customer->id,
            "email" => $this->context->customer->email);
        if (!empty($phone)) {
            $identity = array_merge($identity, array("phone" => $phone));
        }

        $info = Tools::jsonEncode($identity);

        $cookie->__set('_ampIdent', $info);
    }

    /*
     * Implement HookOrderConfirmation Function;
     * Get detail's of order, Like total product, Order Id, Price, Coopan, etc;
     * Send detail on izooto via CURL;
     */

    public function hookorderConfirmation($params)
    {
        $order = $params['order'];
        $cookies = $params['cookie'];
        $products = $params['order']->getProducts();
        $productarray = array();
        $currency = new CurrencyCore($cookies->id_currency);

        $i = $j = 0;
        // Get Total Product's and Product's Detail;
        foreach ($products as $value) {
            $productarray['product_title'] = $value['product_name'];
            $productarray['product_price'] = (float) $value['price'];
            $productarray['product_id'] = (int) $value['product_id'];
            $productarray['product_quantity'] = (int) $value['product_quantity'];
//            $productarray[$i]['categories'] = $this->getCategoryNamesByProduct($value['product_id'], true);
//            $productarray[$i]['image_url'] = $image_url;
            $i++;
        }

        $discount = $order->getDiscounts();
        $coopan = '';

        foreach ($discount as $dis) {
            $coopan = $coopan == '' ? $dis['name'] : $coopan . ', '.$dis['name'];
            $j++;
        }

        //Get Order Detail;

        $orderinfo = array('order_id' => $order->id,
            'total' => (float) $order->total_paid,
//            'shipping' => $order->total_shipping,
//            'tax' => $order->total_paid_tax_incl - $order->total_paid_tax_excl,
            'discount' => (float) $order->total_discounts,
            'cart_value' => (float) $order->total_paid_tax_excl,
//            'shoppingCartNo'=>$this->context->cart->id,
            'coupon' => $coopan,
//            'status' => $order->current_state,
            'payment_method' => $order->module,
            'product_count' => $i,
            'currency' => $currency->iso_code
        );

        $orderarray = json_encode(array_merge($productarray, $orderinfo));
        $izootoparams = array_merge($this->izootoSystemProperty("order_placed"), array("val" => $orderarray));

        $requesturl = 'https://et.izooto.com/evt';
        $result = $this->izootoMakeRequest($requesturl, $izootoparams);
        return $result;
    }

    /*
     * Implement hookActionBeforeCartUpdateQty Function;
     * Track Cart Update and Add To Cart Event;
     */

    public function hookactionBeforeCartUpdateQty($params)
    {
        $cookie = $this->context->cookie;
        $this->context->smarty->assign('undefind', $params);
        $cookie->__set('xlcn_izooto_cart', true);
    }

    /*
     * Get product Category in Array;
     */

    private function getCategoryNamesByProduct($id, $array = true)
    {

        $c_categorie = Product::getProductCategoriesFull($id, $this->context->cookie->id_lang);
        if (!is_array($c_categorie)) {
            if ($array) {
                return array();
            } else {
                return '[]';
            }
        }
        $_categories = array_reverse($c_categorie);
        $categories = array();
        if ($array) {
            foreach ($_categories as $key) {
                $ncategory = new Category($key['id_category'], $this->context->cookie->id_lang);
                if ($ncategory->is_root_category) {
                    array_push($categories, array(
                        'cat_name' => $key['name'] != null ? $key['name'] : "",
                        'cat_id' => $key['id_category'] != null ? $key['id_category'] : "",
                        'parent_cat_id' => 0
                    ));
                } else {
                    array_push($categories, array(
                        'cat_name' => $key['name'],
                        'cat_id' => $key['id_category'],
                        'parent_cat_id' => $ncategory->id_parent
                    ));
                }
            }
        } else {
            $categories = '[';
            $c = 0;
            foreach ($c_categorie as $category) {
                $c++;
                $categories .= '"' . $category['n'] . '",';
                if ($c == 5) {
                    break;
                }
            }
            $categories = rtrim($categories, ',');
            $categories .= ']';
        }

        return $categories;
    }

    public function getIdentity()
    {
        $mo = new Mobile_Detect();
        $md = $mo->getHttpHeaders();
        $ar = explode(';', $md['HTTP_COOKIE']);
        $det = array();
        foreach ($ar as $val) {
            $record1 = explode('=', $val);
            $det[trim($record1[0])] = trim($record1[1]);
        }
        return $det;
    }

    public function izootoGetIdentification()
    {
        $cookie = $this->context->cookie;
        $id = array();
        $id = $this->getIdentity();
        $array = array();
        if (!empty($cookie->__get('_ampIdent'))) {
            $ident = Tools::jsonDecode($cookie->__get('_ampIdent'), true);
            $array = array_merge($array, array("customer_id" => $ident['customer_id'],
                "email" => $ident['email']));
            if (!empty($ident['phone'])) {
                $array = array_merge($array, array("phone" => $ident['phone']));
            }
        } else {
            $array = array_merge($array, array("token" => isset($id['_ampUITN']) ? $id['_ampUITN'] : ""));
        }
        return $array;
    }

    public function izootoSystemProperty($event_name)
    {
        $tokenSaved = "";
        
        if (isset($_COOKIE['iztoken']) && $_COOKIE['iztoken'] != "") {
            $tokenSaved = $_COOKIE['iztoken'];
        } else {
            return false;
        }
        
        $tokenSaved = $this->extractToken($tokenSaved);
        $properties = array(
            'bKey' => $tokenSaved,
            'pid' => Configuration::get('IZOOTO_PID'),
            'et' => "evt",
            'act' => $event_name,
        );
        return $properties;
    }

    public function extractToken($token)
    {
        $tokenObj = json_decode($token, true);
        if (isset($tokenObj["endpoint"])) {
            $enp = $tokenObj["endpoint"];
        } else {
            $enp = $token;
        }
        $o = $enp;

        $prefix = array(
           "fcm" => "https://fcm.googleapis.com/fcm/send/",
           "chrome" => "https://android.googleapis.com/gcm/send/",
           "ffox" => "https://updates.push.services.mozilla.com/wpush/",
           "uc" => "https://uccm-intl.ucweb.com/wpush/m/"
        );

        foreach ($prefix as $key => $index) {
            if (strstr($enp, $index)) {
                $o = str_replace($index, "", $enp);
                return $o;
            }
        }
        if (strstr($enp, "?token=")) {
            $o = Tools::substr($enp, strpos($enp, "=")+1);
        }
        return $o;
    }
    
    /*
     * Implement CURL Function for send data on izooto;
     */

    public function izootoMakeRequest($requesturl, $params)
    {
        try {
            $data_string = http_build_query($params);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $requesturl);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);

            $result = curl_exec($ch);
        } catch (Exception $e) {
        }
        return $result;
    }
}
