<?php

class ControllerExtensionModuleIzooto extends Controller {

    private $error = array();
    public $data = false;
    public $izooto_account = false;
    public $izooto_api_url = "api.izooto.com";
    public $filePermission = false;
    
    public function install() {

    }

    public function uninstall() {
        try {
            $opencart_path = realpath(dirname(__FILE__) . '/../../../../') . '/';
            $mf = "manifest.json";
            $sw = "service-worker.js";

            $fmf = fopen($opencart_path . $mf, 'w');
            fwrite($fmf, "", strlen($str));
            fclose($fmf);

            $fsw = fopen($opencart_path . $sw, 'w');
            fwrite($fsw, "", strlen($str));
            fclose($fsw);
        } catch (Exception $e) {
//            $this->error['warning'] = $this->language->get('error_file_write');
//            return !$this->error;
        }
    }
    
    private function fileSetting() {
        $opencart_path = realpath(dirname(__FILE__) . '/../../../../') . '/';
        $mf = "manifest.json";
        $sw = "service-worker.js";

        try {
            if (file_exists($opencart_path . $mf) && file_exists($opencart_path . $sw)) {
                if (is_writable($opencart_path . $mf) && is_writable($opencart_path . $sw)) {
                    $this->filePermission = TRUE;
                } else {
                    $this->error["warning"] = $opencart_path . $sw . " OR ".  $opencart_path . $mf ." File Is not writable::";
                }
            } else {
                $this->error["warning"] = $opencart_path . $sw . " OR ".  $opencart_path . $mf ." File Not exist::";
            }
        } catch (Exception $ex) {
            $this->error["warning"] = "Exception In file Writing:: ".$ex->getMessage();
        }
    }

    public function index() {
        $this->load->language('extension/module/izooto');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
//        $this->load->model('extention/izooto');
        $this->fileSetting();
        
        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate() && $this->getIzootoSetting() && $this->setIzootoDependency()) {

            $this->model_setting_setting->editSetting('izooto', $this->izooto_account);
            //Write the settings to the izooto-proxy file 

            $this->session->data['success'] = $this->language->get('text_success');


            $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit'] = $this->language->get('text_edit');

        $data['text_module'] = $this->language->get('text_module');
        $data['entry_api_key'] = $this->language->get('entry_api_key');
        $data['entry_tracker_location'] = $this->language->get('entry_tracker_location');
        $data['entry_site_id'] = $this->language->get('entry_site_id');

        $data['help_api_key'] = $this->language->get('help_api_key');
        $data['help_tracker_location2'] = $this->language->get('help_tracker_location2');
        $data['help_site_id2'] = $this->language->get('help_site_id2');
        $data['help_enable'] = $this->language->get('help_enable');


        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }
        if (isset($this->error['api_key'])) {
            $data['error_api_key'] = $this->error['api_key'];
        } else {
            $data['error_api_key'] = '';
        }

        if (isset($this->error['site_id'])) {
            $data['error_site_id'] = $this->error['site_id'];
        } else {
            $data['error_site_id'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
        );

        if (!isset($this->request->get['module_id'])) {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/izooto', 'token=' . $this->session->data['token'], true)
            );
        } else {
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/izooto', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
            );
        }
        if (!isset($this->request->get['module_id'])) {
            $data['action'] = $this->url->link('extension/module/izooto', 'token=' . $this->session->data['token'], true);
        } else {
            $data['action'] = $this->url->link('extension/module/izooto', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true);
        }

        $data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

        if (isset($this->request->post['izooto_title'])) {
            $data['izooto_title'] = $this->request->post['izooto_title'];
        } else {
            $data['izooto_title'] = $this->config->get('izooto_title');
        }

//        if (isset($this->request->post['izooto_api_key'])) {
//            $data['izooto_api_key'] = $this->request->post['izooto_api_key'];
//        } else {
//            $data['izooto_api_key'] = $this->config->get('izooto_api_key');
//        }


        if (isset($this->request->post['izooto_site_id'])) {
            $data['izooto_site_id'] = $this->request->post['izooto_site_id'];
        } else {
            $data['izooto_site_id'] = $this->config->get('izooto_site_id');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->data = $data;
        $this->response->setOutput($this->load->view('extension/module/izooto.tpl', $data));
    }

    public function validate() {

//        if (strlen($this->request->post['izooto_api_key']) <= 31) {
//            $this->error['warning'] = $this->language->get('error_api_key');
//        }

        if (empty($this->request->post['izooto_site_id'])) {
            $this->error['warning'] = $this->language->get('error_site_id');
        }

//        if (empty($this->request->post['izooto_api_key']) || is_numeric($this->request->post['izooto_api_key'])) {
//            $this->error['warning'] = $this->language->get('error_api_key');
//        }

        if (!$this->user->hasPermission('modify', 'extension/module/izooto')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
//        return 1;
    }

    private function getIzootoSetting() {

//        print_r($this->request->post);
        $requesturl = "http://" . $this->izooto_api_url . "/wp/index.php?key=" . $this->request->post["izooto_site_id"] . "&version=3.3.5";
//       echo "<br>Final Url::: ".$requesturl.PHP_EOL;
        try {
            $ch = curl_init($requesturl);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

            $result = curl_exec($ch);
        } catch (Exception $e) {
//            print_r($e);
            return false;
        }
        $izooto_detail = json_decode($result, 1);
//        print_r($izooto_detail);
//        die("in geting site details:::::");
        if (!$izooto_detail['error']) {
//            $this->izooto_account["izooto_api_key"] = $this->request->post["izooto_api_key"];
            $this->izooto_account["izooto_site_id"] = $this->request->post["izooto_site_id"];
            $this->izooto_account["izooto_uid"] = $izooto_detail["uid"];
            $this->izooto_account["izooto_pid"] = $izooto_detail["pid"];
            $this->izooto_account["izooto_gcm_sender_id"] = $izooto_detail["gcmSenderId"];
            $this->izooto_account["izooto_js_url"] = $izooto_detail["js-url"];
            $this->izooto_account["izooto_sw_url"] = $izooto_detail["sw-url"];
            $this->izooto_account["izooto_acc_app_key"] = $izooto_detail["appKey"];
            $this->izooto_account["izooto_acc_subdomain"] = $izooto_detail["subdomain"];
            $this->izooto_account["izooto_acc_phone"] = $izooto_detail["phone"];
            $this->izooto_account["izooto_acc_name"] = $izooto_detail["name"];
            $this->izooto_account["izooto_acc_email"] = $izooto_detail["email"];
        } else {
            $this->izooto_account["izooto_api_key"] = $this->request->post["izooto_api_key"];
            $this->izooto_account["izooto_site_id"] = $this->request->post["izooto_site_id"];
            
            $this->error['warning'] = $this->language->get('error_site_token');
            return !$this->error;
        }

        return true;
    }

    private function setIzootoDependency() {
        try {
            $opencart_path = realpath(dirname(__FILE__) . '/../../../../') . '/';
            $mf = "manifest.json";
            $sw = "service-worker.js";
            
//            $fmf = fopen($opencart_path . $mf, 'w');
            $str = '{"gcm_sender_id": "' . $this->izooto_account["izooto_gcm_sender_id"] . '"}';
//            fwrite($fmf, $str, strlen($str));
//            fclose($fmf);
            file_put_contents($opencart_path . $mf, $str);

//            $fsw = fopen($opencart_path . $sw, 'w');
            $str = "importScripts('https://" . $this->izooto_account["izooto_sw_url"] . "');";
//            fwrite($fsw, $str, strlen($str));
//            fclose($fsw);
            file_put_contents($opencart_path . $sw, $str);

        } catch (Exception $e) {

            $this->error['warning'] = $this->language->get('error_file_write');
            return !$this->error;
        }

        return true;
    }

}

?>